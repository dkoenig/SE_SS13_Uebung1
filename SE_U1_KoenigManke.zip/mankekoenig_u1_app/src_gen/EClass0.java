
/*
 * @author: K?nig, Manke
 *
 */
	public class EClass0 {
	
	

	} 
