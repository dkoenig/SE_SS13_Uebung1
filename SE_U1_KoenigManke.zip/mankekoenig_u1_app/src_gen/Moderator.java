
/*
 * @author: K?nig, Manke
 *
 */
	public class Moderator {
	
		private invalid Name: String; 
		private invalid Alter: int; 
		private invalid Geschlecht: String; 
		private invalid Herzschlag: int; 
		private invalid Moderationskarten: int; 
		private invalid Fachwissen: int; 
	
		public invalid moderieren: boolean() { 
		// ToDo
		}

		public invalid getName: String() { 
		// ToDo
		return this.Name: String;
		}
		public void setName: String(invalid Name: String) { 
		// ToDo
		this.Name: String = Name: String;
		}
		public invalid getAlter: int() { 
		// ToDo
		return this.Alter: int;
		}
		public void setAlter: int(invalid Alter: int) { 
		// ToDo
		this.Alter: int = Alter: int;
		}
		public invalid getGeschlecht: String() { 
		// ToDo
		return this.Geschlecht: String;
		}
		public void setGeschlecht: String(invalid Geschlecht: String) { 
		// ToDo
		this.Geschlecht: String = Geschlecht: String;
		}
		public invalid getHerzschlag: int() { 
		// ToDo
		return this.Herzschlag: int;
		}
		public void setHerzschlag: int(invalid Herzschlag: int) { 
		// ToDo
		this.Herzschlag: int = Herzschlag: int;
		}
		public invalid getModerationskarten: int() { 
		// ToDo
		return this.Moderationskarten: int;
		}
		public void setModerationskarten: int(invalid Moderationskarten: int) { 
		// ToDo
		this.Moderationskarten: int = Moderationskarten: int;
		}
		public invalid getFachwissen: int() { 
		// ToDo
		return this.Fachwissen: int;
		}
		public void setFachwissen: int(invalid Fachwissen: int) { 
		// ToDo
		this.Fachwissen: int = Fachwissen: int;
		}
	} 
